-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 09:05 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deliverit`
--

-- --------------------------------------------------------

--
-- Table structure for table `businesspartner`
--

CREATE TABLE `businesspartner` (
  `Partner_ID` varchar(5) NOT NULL,
  `Partner_Name` varchar(255) NOT NULL,
  `Partner_Address` varchar(255) NOT NULL,
  `Partner_Email` varchar(255) NOT NULL,
  `Partner_Phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `businesspartner`
--

INSERT INTO `businesspartner` (`Partner_ID`, `Partner_Name`, `Partner_Address`, `Partner_Email`, `Partner_Phone`) VALUES
('P01', 'KFC', 'Tower 1, level 11, VSquare@PJ City Centre,\r\nJalan Utara, 46200 Petaling Jaya, \r\nSelangor Darul Ehsan', 'kfcholdings.com.my/support', '03-79338-888'),
('P02', 'Mcdonalds', 'Ronald McDonald House Charities Malaysia,\r\nLevel 6, Bangunan TH, Damansara Uptown 3,\r\nNo 3, Jalan SS', 'rmhc@my.mcd.com', '+603-7843 3388'),
('P03', 'pizza hut', 'TOWER 1 VSQUARE @PJ CITY CENTRE\r\nLEVEL 7 JALAN UTARA, 46200\r\nPETALING JAYA, SELANGOR DARUL EHSAN', 'https://www.facebook.com/pizzahutmalaysia/', '603. 7933 8888');

-- --------------------------------------------------------

--
-- Table structure for table `customerinformation`
--

CREATE TABLE `customerinformation` (
  `ID` varchar(5) NOT NULL,
  `Name` text NOT NULL,
  `IC` varchar(100) NOT NULL,
  `Email` text NOT NULL,
  `Address` text NOT NULL,
  `PhoneNo` int(11) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `chat_log` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerinformation`
--

INSERT INTO `customerinformation` (`ID`, `Name`, `IC`, `Email`, `Address`, `PhoneNo`, `Password`, `chat_log`) VALUES
('C04', 'Afiq Danial', '000512141453', 'piko@gmail.com', '27 , Jalan Temabaga 37/55 , Seksyen 27 , Shah Alam , Selangor', 1124428424, 'pikohensem', ''),
('C12', 'Syafikah binti Ismail', '990102141432', 'pikah@gmail.com', 'Layby 3, Hentian Sebelah PJS 9 47600 Jaya, LDP, Bandar Sunway, 47100 Petaling Jaya, Selangor.', 132458633, 'syaf123', ''),
('C23', 'Ain Mutaqorrobin bin Muhammad Fadzil', '000412141421', 'ain@gmail.com', '28, Jalan Pulau Lumut U10/73a, Alam Budiman, 40170 Shah Alam, Selangor', 142321324, 'ain123', ''),
('C24', 'Tee Lee Huang', '980212140523', 'lee@gmail.com', '13 Jalan SS 22/10 Damansara Utama 46200 Petaling Jaya Selangor', 1132452564, 'lee123', 'No Messages Yet');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `Delivery_ID` varchar(5) NOT NULL,
  `Runner_ID` varchar(5) NOT NULL,
  `Cust_ID` varchar(5) NOT NULL,
  `Total_Delivery` double(5,2) NOT NULL,
  `Delivery_Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`Delivery_ID`, `Runner_ID`, `Cust_ID`, `Total_Delivery`, `Delivery_Status`) VALUES
('D208', 'R01', 'C12', 94.20, 'Delivered'),
('D395', 'R03', 'C04', 48.70, 'Delivered'),
('D621', 'R03', 'C24', 377.50, 'Delivered'),
('D708', '', 'C04', 103.60, 'New Order'),
('D865', 'R01', 'C12', 54.90, 'Delivered'),
('D888', 'R01', 'C23', 193.50, 'Delivered'),
('D896', '', 'C12', 284.50, 'New Order'),
('D998', 'R01', 'C23', 128.50, 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `foodorder`
--

CREATE TABLE `foodorder` (
  `Order_ID` varchar(5) NOT NULL,
  `Food_Name` varchar(50) NOT NULL,
  `Food_Price` double(5,2) NOT NULL,
  `Food_Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `foodorder`
--

INSERT INTO `foodorder` (`Order_ID`, `Food_Name`, `Food_Price`, `Food_Quantity`) VALUES
('O482', 'Mcd Red Valvet Cake', 8.00, 1),
('O482', 'Mcd Pancake', 10.90, 1),
('O482', 'Mcd Scrambled Egg Sandwich', 14.90, 1),
('O482', 'Mcd Sundae Choclate', 4.90, 1),
('O850', 'KFC Zinger Porridge', 16.00, 2),
('O850', 'KFC Classic Rice', 35.40, 6),
('O850', 'KFC Zinger Burger', 10.90, 1),
('O850', 'KFC Cheezy Wedges', 19.60, 4),
('O850', 'KFC Crispy Tenders', 11.70, 3),
('O249', 'Mcd Nasi Lemak', 39.50, 5),
('O249', 'Mcd Scrambled Egg Sandwich', 44.70, 3),
('O883', 'Pizza Heart Aloha Chicken', 38.00, 1),
('O883', 'Pizza Heart Hawaii Chicken', 71.80, 2),
('O883', 'Pizza Kari Raya Chicken', 164.70, 3),
('O268', 'KFC Zinger Porridge', 40.00, 5),
('O268', 'KFC Cheezy Wedges', 4.90, 1),
('O196', 'KFC Zinger Porridge', 80.00, 10),
('O196', 'KFC Zinger Burger', 54.50, 5),
('O196', 'KFC Cheezy Wedges', 49.00, 10),
('O247', 'Mcd Red Valvet Cake', 48.00, 6),
('O247', 'Mcd Pancake', 10.90, 1),
('O247', 'Mcd Scrambled Egg Sandwich', 59.60, 4),
('O993', 'Pizza Heart Aloha Chicken', 152.00, 4),
('O993', 'Pizza Heart Hawaii Chicken', 35.90, 1),
('O993', 'Pizza Heart Hawaii Pepperoni', 179.60, 4);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_ID` varchar(5) NOT NULL,
  `Delivery_ID` varchar(5) NOT NULL,
  `Partner_ID` varchar(5) NOT NULL,
  `Order_Date` varchar(10) NOT NULL,
  `Order_Address` varchar(255) NOT NULL,
  `Total_FoodPrice` double(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Order_ID`, `Delivery_ID`, `Partner_ID`, `Order_Date`, `Order_Address`, `Total_FoodPrice`) VALUES
('O196', 'D888', 'P01', '14/06/2021', 'UM KK12', 183.50),
('O247', 'D998', 'P02', '14/06/2021', 'UM KK2', 118.50),
('O249', 'D208', 'P02', '14/06/2021', 'UM Main Gate', 84.20),
('O268', 'D865', 'P01', '14/06/2021', '42 Jalan Tembakau Taman Tembakau 41620 Petaling Jaya Selangor', 44.90),
('O482', 'D395', 'P02', '14/06/2021', 'UPM Main Gate', 38.70),
('O850', 'D708', 'P01', '14/06/2021', 'UPM Main Gate', 93.60),
('O883', 'D896', 'P03', '14/06/2021', '12 Jalan SS 20/10 Damansara Kim 40600 Petaling Jaya Selangor ', 274.50),
('O993', 'D621', 'P03', '14/06/2021', 'PosLaju Petaling Jaya', 367.50);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_ID` varchar(5) NOT NULL,
  `Order_ID` varchar(5) NOT NULL,
  `Payment_Amount` double(5,2) NOT NULL,
  `Card_number` varchar(20) NOT NULL,
  `Card_Name` varchar(100) NOT NULL,
  `Card_CVV` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_ID`, `Order_ID`, `Payment_Amount`, `Card_number`, `Card_Name`, `Card_CVV`) VALUES
('P117', 'O850', 103.60, '67238912453623', 'MAYBANK Mastercard', '223'),
('P286', 'O482', 48.70, '1234123123457895', 'CIMB Mastercard', '212'),
('P463', 'O249', 94.20, '5463728309451234', 'CIMB Mastercard', '121'),
('P628', 'O247', 128.50, '66346274334', 'CIMB Mastercard', '664'),
('P753', 'O993', 377.50, '1231414314314', 'MAYBANK VISA', '621'),
('P788', 'O196', 193.50, '12325263274', 'CIMB VISA', '772'),
('P960', 'O268', 54.90, '32423423234', 'CIMB Mastercard', '716'),
('P992', 'O883', 284.50, '5362623624724', 'Public Bank VISA', '345');

-- --------------------------------------------------------

--
-- Table structure for table `runner`
--

CREATE TABLE `runner` (
  `Runner_ID` varchar(5) NOT NULL,
  `Runner_Name` varchar(255) NOT NULL,
  `Runner_ICNo` varchar(255) NOT NULL,
  `Runner_Email` varchar(255) NOT NULL,
  `Runner_Address` varchar(255) NOT NULL,
  `Runner_PlateNo` varchar(255) NOT NULL,
  `Runner_PhoneNo` varchar(255) NOT NULL,
  `Runner_Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `runner`
--

INSERT INTO `runner` (`Runner_ID`, `Runner_Name`, `Runner_ICNo`, `Runner_Email`, `Runner_Address`, `Runner_PlateNo`, `Runner_PhoneNo`, `Runner_Password`) VALUES
('R01', 'NARRESH NAIDU', '000712070657', 'narresh@gmail.com', 'No. 41, Jalan Bola Jaring 13/15. Seksyen 13, 40100 Shah Alam, Selangor', 'PNX7655', '01124092575', 'narresh1207'),
('R03', 'FATHUL AMIN', '000321082321', 'fathul@gmail.com', 'Lot F23-F45, Level 1, Bangunan IDCC Shah Alam, Jalan Pahat L 15/L, Seksyen 15, 40200 Shah Alam , Selangor', 'RW323', '0193425738', 'fathul');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `businesspartner`
--
ALTER TABLE `businesspartner`
  ADD PRIMARY KEY (`Partner_ID`);

--
-- Indexes for table `customerinformation`
--
ALTER TABLE `customerinformation`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`Delivery_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_ID`);

--
-- Indexes for table `runner`
--
ALTER TABLE `runner`
  ADD PRIMARY KEY (`Runner_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
